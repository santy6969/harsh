// src/router/index.js
import Vue from 'vue'
import VueRouter from 'vue-router'
import SignupForm from '../components/views/auth/SignupForm.vue'
import LoginForm from '@/components/views/auth/LoginForm.vue'
import CustomerDashboard from '@/components/views/CustomerDashboard.vue'
import AdminDashboard from '@/components/views/AdminDashboard.vue'
import ProfessionalDashboard from '@/components/views/ProfessionalDashboard.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/signup',
    name: 'Signup',
    component: SignupForm
  },
  {
    path: '/login',
    name: 'LoginForm',
    component: LoginForm
  },
  {
    path: '/user/customer',
    name: 'CustomerDashboard',
    component: CustomerDashboard,
    meta: { 
      requiresAuth: true,
      role: 'Customer'
    }
  },
  {
    path: '/admin',
    name: 'AdminDashboard',
    component: AdminDashboard,
    meta: { 
      requiresAuth: true,
      role: 'Admin'
    }
  },
  {
    path: '/user/professional',
    name: 'ProfessionalDashboard',
    component: ProfessionalDashboard,
    meta: { 
      requiresAuth: true,
      role: 'Professional'
    }
  },
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '*',
    redirect: '/login'
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})


export default router