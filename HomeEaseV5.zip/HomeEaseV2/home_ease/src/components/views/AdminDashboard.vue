<!-- AdminDashboard.vue -->
<template>
  <div>
    <!-- Navigation Bar -->
    <b-navbar variant="dark" type="dark" class="mb-4 bg-primary">
      <b-navbar-brand>Admin Dashboard</b-navbar-brand>
      <b-navbar-nav class="ml-auto">
        <b-nav-item-dropdown right>
          <template #button-content>
            <b-icon icon="person-fill" class="mr-1"></b-icon>
            {{ userInfo.full_name || 'Admin' }}
          </template>
          <b-dropdown-item @click="handleLogout">
            <b-icon icon="box-arrow-right" class="mr-1"></b-icon>
            Logout
          </b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-navbar>

    <div class="dashboard container py-4">
      <!-- Statistics Cards -->
      <b-row class="mb-4">
        <b-col md="4" class="mb-3">
          <b-card bg-variant="primary" text-variant="white">
            <h5 class="card-title">Total Customers</h5>
            <h2>{{ stats.total_customers || 0 }}</h2>
          </b-card>
        </b-col>
        <b-col md="4" class="mb-3">
          <b-card bg-variant="success" text-variant="white">
            <h5 class="card-title">Total Professionals</h5>
            <h2>{{ stats.total_professionals || 0 }}</h2>
          </b-card>
        </b-col>
        <b-col md="4" class="mb-3">
          <b-card bg-variant="warning" text-variant="white">
            <h5 class="card-title">Pending Verifications</h5>
            <h2>{{ stats.pending_verifications || 0 }}</h2>
          </b-card>
        </b-col>
      </b-row>

      <!-- Main Content Tabs -->
      <b-card no-body>
        <b-tabs pills card vertical>
          <!-- Services Tab -->
          <b-tab title="Services" active>
            <b-card-text>
              <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="mb-0">Manage Services</h4>
                <b-button variant="primary" @click="showAddServiceModal">
                  <b-icon icon="plus"></b-icon> Add Service
                </b-button>
              </div>
              
              <b-table
                :items="services"
                :fields="serviceFields"
                striped
                hover
                responsive
              >
                <template #cell(base_price)="{ item }">
                  ${{ item.base_price }}
                </template>
              </b-table>
            </b-card-text>
          </b-tab>

          <!-- Professionals Tab -->
          <b-tab title="Professionals">
            <b-card-text>
              <h4 class="mb-3">Pending Verifications</h4>
              <div v-if="pendingProfessionals.length === 0" class="text-center py-3">
                <p class="mb-0">No pending verifications</p>
              </div>
              <b-table
                v-else
                :items="pendingProfessionals"
                :fields="professionalFields"
                striped
                hover
                responsive
              >
                <template #cell(actions)="{ item }">
                  <b-button 
                    variant="success" 
                    size="sm"
                    :disabled="verifying"
                    @click="verifyProfessional(item)"
                  >
                    <b-icon icon="check"></b-icon> Verify
                  </b-button>
                </template>
              </b-table>
            </b-card-text>
          </b-tab>

          <!-- Users Tab -->
          <b-tab title="Users">
            <b-card-text>
              <h4 class="mb-3">User Management</h4>
              <div v-if="users.length === 0" class="text-center py-3">
                <p class="mb-0">No users found</p>
              </div>
              <b-table
                v-else
                :items="users"
                :fields="userFields"
                striped
                hover
                responsive
              >
                <template #cell(status)="{ item }">
                  <b-badge :variant="item.status === 'active' ? 'success' : 'danger'">
                    {{ item.status }}
                  </b-badge>
                </template>
                <template #cell(actions)="{ item }">
                  <b-button 
                    :variant="item.status === 'active' ? 'danger' : 'success'"
                    size="sm"
                    @click="toggleUserStatus(item)"
                  >
                    {{ item.status === 'active' ? 'Block' : 'Unblock' }}
                  </b-button>
                </template>
              </b-table>
            </b-card-text>
          </b-tab>
        </b-tabs>
      </b-card>
    </div>

    <!-- Add Service Modal -->
    <b-modal
      id="service-modal"
      title="Add Service"
      hide-footer
      @hidden="resetServiceForm"
    >
      <b-form @submit.prevent="submitService">
        <b-form-group label="Service Name">
          <b-form-input
            v-model="serviceForm.name"
            required
            placeholder="Enter service name"
          ></b-form-input>
        </b-form-group>

        <b-form-group label="Description">
          <b-form-textarea
            v-model="serviceForm.description"
            required
            placeholder="Enter service description"
            rows="3"
          ></b-form-textarea>
        </b-form-group>

        <b-form-group label="Base Price">
          <b-form-input
            v-model="serviceForm.base_price"
            type="number"
            min="0"
            step="0.01"
            required
            placeholder="Enter base price"
          ></b-form-input>
        </b-form-group>

        <b-form-group label="Category">
          <b-form-select
            v-model="serviceForm.category_id"
            :options="categoryOptions"
            required
          ></b-form-select>
        </b-form-group>

        <b-form-group label="Estimated Time (hours)">
          <b-form-input
            v-model="serviceForm.estimated_time"
            type="number"
            min="0"
            step="0.5"
            placeholder="Enter estimated time"
          ></b-form-input>
        </b-form-group>

        <div class="d-flex justify-content-end">
          <b-button
            variant="secondary"
            class="mr-2"
            @click="$bvModal.hide('service-modal')"
          >
            Cancel
          </b-button>
          <b-button
            type="submit"
            variant="primary"
            :disabled="isSubmitting"
          >
            {{ isSubmitting ? 'Saving...' : 'Save' }}
          </b-button>
        </div>
      </b-form>
    </b-modal>

    <!-- Logout Confirmation Modal -->
    <b-modal
      id="logout-confirm-modal"
      title="Confirm Logout"
      ok-variant="danger"
      ok-title="Logout"
      @ok="confirmLogout"
    >
      <p>Are you sure you want to log out?</p>
    </b-modal>
  </div>
</template>

<script>
export default {
  name: 'AdminDashboard',
  data() {
    return {
      userInfo: JSON.parse(localStorage.getItem('userInfo') || '{}'),
      stats: {},
      services: [],
      serviceFields: [
        { key: 'name', label: 'Service Name' },
        { key: 'description', label: 'Description' },
        { key: 'base_price', label: 'Base Price' }
      ],
      serviceForm: {
        name: '',
        description: '',
        base_price: '',
        category_id: '',
        estimated_time: ''
      },
      pendingProfessionals: [],
      professionalFields: [
        { key: 'full_name', label: 'Name' },
        { key: 'email', label: 'Email' },
        { key: 'years_of_experience', label: 'Experience' },
        { key: 'actions', label: 'Actions' }
      ],
      users: [],
      userFields: [
        { key: 'full_name', label: 'Name' },
        { key: 'email', label: 'Email' },
        { key: 'role', label: 'Role' },
        { key: 'status', label: 'Status' },
        { key: 'actions', label: 'Actions' }
      ],
      categories: [],
      isSubmitting: false,
      verifying: false
    }
  },
  computed: {
    categoryOptions() {
      return this.categories.map(category => ({
        value: category.id,
        text: category.name
      }))
    }
  },
  mounted() {
    this.fetchInitialData()
  },
  methods: {
    async fetchInitialData() {
      try {
        await Promise.all([
          this.fetchStats(),
          this.fetchServices(),
          this.fetchCategories(),
          this.fetchPendingProfessionals(),
          this.fetchUsers()
        ])
      } catch (error) {
        console.error('Error fetching initial data:', error)
      }
    },
    async fetchStats() {
      try {
        const token = localStorage.getItem('token')
        const response = await fetch('http://127.0.0.1:5000/api/admin/dashboard/stats', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to fetch stats')
        }
        this.stats = await response.json()
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    async fetchServices() {
      try {
        const token = localStorage.getItem('token')
        const response = await fetch('http://127.0.0.1:5000/api/admin/services', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to fetch services')
        }
        this.services = await response.json()
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    async fetchCategories() {
      try {
        const response = await fetch('http://127.0.0.1:5000/api/service-categories')
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to fetch categories')
        }
        this.categories = await response.json()
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    async fetchUsers() {
      try {
        const token = localStorage.getItem('token')
        const response = await fetch('http://127.0.0.1:5000/api/admin/users', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to fetch users')
        }
        this.users = await response.json()
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    async fetchPendingProfessionals() {
      try {
        const token = localStorage.getItem('token')
        const response = await fetch('http://127.0.0.1:5000/api/admin/professionals/pending', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to fetch pending professionals')
        }
        this.pendingProfessionals = await response.json()
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    showAddServiceModal() {
      this.resetServiceForm()
      this.$bvModal.show('service-modal')
    },
    async submitService() {
      try {
        this.isSubmitting = true
        const token = localStorage.getItem('token')
        
        const formattedData = {
          ...this.serviceForm,
          base_price: parseFloat(this.serviceForm.base_price),
          category_id: parseInt(this.serviceForm.category_id),
          estimated_time: this.serviceForm.estimated_time ? parseFloat(this.serviceForm.estimated_time) : null
        }
        console.log(formattedData)
        
        const response = await fetch('http://127.0.0.1:5000/api/admin/services', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(formattedData)
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to add service')
        }

        this.$bvToast.toast('Service added successfully', {
          title: 'Success',
          variant: 'success'
        })
        
        this.$bvModal.hide('service-modal')
        await this.fetchServices()
        
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      } finally {
        this.isSubmitting = false
      }
    },
    async verifyProfessional(professional) {
      try {
        this.verifying = true
        const token = localStorage.getItem('token')
        professional.loading = true
        
        const response = await fetch(`http://127.0.0.1:5000/api/admin/professionals/verify/${professional.id}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to verify professional')
        }
        
        // Refresh the data
        this.fetchStats()  // This will update the stats
        const pendingResponse = await fetch('http://127.0.0.1:5000/api/admin/professionals/pending', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        
        if (!pendingResponse.ok) {
          throw new Error('Failed to refresh professional list')
        }
        
        this.pendingProfessionals = await pendingResponse.json()
        
        this.$bvToast.toast('Professional verified successfully', {
          title: 'Success',
          variant: 'success'
        })
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      } finally {
        professional.loading = false
        this.verifying = false
      }
    },
    async toggleUserStatus(user) {
      try {
        const token = localStorage.getItem('token')
        const response = await fetch(`http://127.0.0.1:5000/api/admin/users/block/${user.id}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to update user status')
        }
        
        await this.fetchUsers()
        
        this.$bvToast.toast(`User ${user.status === 'active' ? 'blocked' : 'unblocked'} successfully`, {
          title: 'Success',
          variant: 'success'
        })
      } catch (error) {
        this.$bvToast.toast(error.message, {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    resetServiceForm() {
      this.serviceForm = {
        name: '',
        description: '',
        base_price: '',
        category_id: '',
        estimated_time: ''
      }
    },
    handleLogout() {
      this.$bvModal.show('logout-confirm-modal')
    },
    async confirmLogout() {
      try {
        localStorage.removeItem('token')
        localStorage.removeItem('userRole')
        localStorage.removeItem('userInfo')
        
        this.$bvToast.toast('Logged out successfully', {
          title: 'Success',
          variant: 'success',
          toaster: 'b-toaster-top-center'
        })
        
        await this.$router.push('/login')
      } catch (error) {
        console.error('Logout error:', error)
        localStorage.clear()
        await this.$router.push('/login')
      }
    }
  }
}
</script>

<style scoped>
.dashboard {
  margin-top: 1rem;
}

.navbar {
  padding: 0.5rem 1rem;
}

.navbar-brand {
  font-weight: bold;
}

/* Card Hover Effects */
.card {
  transition: transform 0.2s ease-in-out;
}

.card:hover {
  transform: translateY(-5px);
}

/* Table Styles */
.table th {
  background-color: #f8f9fa;
  border-top: none;
}

/* Tab Styles */
.nav-pills .nav-link.active {
  background-color: #007bff;
}

/* Button Spacing */
.btn-group > .btn {
  margin-right: 0.2rem;
}

/* Badge Styles */
.badge {
  padding: 0.5em 0.8em;
}

/* Form Styles */
.form-group {
  margin-bottom: 1.5rem;
}

/* Modal Styles */
.modal-content {
  border-radius: 0.5rem;
}

/* Loading Spinner */
.loading-spinner {
  width: 1rem;
  height: 1rem;
  margin-right: 0.5rem;
}
</style>