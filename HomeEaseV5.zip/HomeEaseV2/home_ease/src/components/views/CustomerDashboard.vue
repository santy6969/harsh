// Customer.vue
<template>
  <div>
    <!-- Navigation Bar -->
    <b-navbar variant="dark" type="dark" class="mb-4 bg-primary">
      <b-navbar-brand>Customer Dashboard</b-navbar-brand>
      <b-navbar-nav class="ml-auto">
        <b-nav-item-dropdown right>
          <template #button-content>
            <b-icon icon="person-fill" class="mr-1"></b-icon>
            {{ userInfo.full_name || 'Customer' }}
          </template>
          <b-dropdown-item @click="handleLogout">
            <b-icon icon="box-arrow-right" class="mr-1"></b-icon>
            Logout
          </b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-navbar>

    <!-- Main Dashboard -->
    <div class="dashboard container py-4">
      <!-- Search and Book Services Section -->
      <b-row class="mb-4">
        <b-col md="6">
          <b-card header="Search Services">
            <b-form-group class="mb-3">
              <b-form-input
                v-model="searchQuery"
                placeholder="Search services..."
                @input="searchServices"
              ></b-form-input>
            </b-form-group>

            <b-form-group class="mb-3">
              <b-form-select
                v-model="selectedCategory"
                :options="categoryOptions"
                @change="searchServices"
              ></b-form-select>
            </b-form-group>
          </b-card>
        </b-col>

        <!-- Service Results -->
        <b-col md="6">
          <b-card header="Available Services">
            <b-overlay :show="loading" rounded="sm">
              <template v-if="services.length === 0">
                <div class="text-center p-4">
                  <p class="mb-0">No services found</p>
                </div>
              </template>
              
              <b-list-group v-else>
                <b-list-group-item v-for="service in services" :key="service.id">
                  <h5>{{ service.name }}</h5>
                  <p class="mb-1">{{ service.description }}</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <p class="mb-0"><strong>Base Price:</strong> ${{ service.base_price }}</p>
                    <b-button variant="primary" size="sm" @click="bookService(service)">
                      Book Now
                    </b-button>
                  </div>
                </b-list-group-item>
              </b-list-group>
            </b-overlay>
          </b-card>
        </b-col>
      </b-row>

      <!-- Service Requests Section -->
      <b-card class="mb-4" header="My Service Requests">
        <b-table
          :items="serviceRequests"
          :fields="requestFields"
          responsive
          striped
          hover
        >
          <template #cell(status)="{ item }">
            <b-badge :variant="getStatusVariant(item.status)">
              {{ item.status }}
            </b-badge>
          </template>

          <template #cell(actions)="{ item }">
            <div class="btn-group">
              <b-button
                v-if="['requested', 'pending'].includes(item.status)"
                variant="warning"
                size="sm"
                class="mr-2"
                @click="showEditModal(item)"
              >
                Edit
              </b-button>
              <b-button
                v-if="['requested', 'pending'].includes(item.status)"
                variant="danger"
                size="sm"
                class="mr-2"
                @click="cancelRequest(item.id)"
              >
                Cancel
              </b-button>
              <b-button
                v-if="item.status === 'completed' && !item.review"
                variant="success"
                size="sm"
                @click="showReviewModal(item)"
              >
                Review
              </b-button>
            </div>
          </template>
        </b-table>
      </b-card>
    </div>

    <!-- Booking Modal -->
    <b-modal
      id="booking-modal"
      title="Book Service"
      hide-footer
    >
      <b-form @submit.prevent="submitBooking">
        <b-form-group label="Service Date">
          <b-form-input
            type="datetime-local"
            v-model="bookingForm.scheduled_date"
            required
          ></b-form-input>
        </b-form-group>

        <b-form-group label="Address">
          <b-form-textarea
            v-model="bookingForm.address"
            required
            rows="3"
          ></b-form-textarea>
        </b-form-group>

        <b-form-group label="Special Instructions">
          <b-form-textarea
            v-model="bookingForm.special_instructions"
            rows="3"
          ></b-form-textarea>
        </b-form-group>

        <div class="d-flex justify-content-end">
          <b-button
            variant="secondary"
            class="mr-2"
            @click="$bvModal.hide('booking-modal')"
          >
            Cancel
          </b-button>
          <b-button
            type="submit"
            variant="primary"
            :disabled="submitting"
          >
            {{ submitting ? 'Submitting...' : 'Submit Request' }}
          </b-button>
        </div>
      </b-form>
    </b-modal>

    <!-- Review Modal -->
    <b-modal
      id="review-modal"
      title="Add Review"
      hide-footer
    >
      <b-form @submit.prevent="submitReview">
        <b-form-group label="Rating">
          <b-form-select
            v-model="reviewForm.rating"
            :options="ratingOptions"
            required
          ></b-form-select>
        </b-form-group>

        <b-form-group label="Comment">
          <b-form-textarea
            v-model="reviewForm.comment"
            required
            rows="3"
          ></b-form-textarea>
        </b-form-group>

        <div class="d-flex justify-content-end">
          <b-button
            variant="secondary"
            class="mr-2"
            @click="$bvModal.hide('review-modal')"
          >
            Cancel
          </b-button>
          <b-button
            type="submit"
            variant="primary"
            :disabled="submitting"
          >
            {{ submitting ? 'Submitting...' : 'Submit Review' }}
          </b-button>
        </div>
      </b-form>
    </b-modal>

    <!-- Edit Request Modal -->
    <b-modal
      id="edit-request-modal"
      title="Edit Service Request"
      hide-footer
    >
      <b-form @submit.prevent="updateRequest">
        <b-form-group label="Service Date">
          <b-form-input
            type="datetime-local"
            v-model="editForm.scheduled_date"
            required
          ></b-form-input>
        </b-form-group>

        <b-form-group label="Address">
          <b-form-textarea
            v-model="editForm.address"
            required
            rows="3"
          ></b-form-textarea>
        </b-form-group>

        <b-form-group label="Special Instructions">
          <b-form-textarea
            v-model="editForm.special_instructions"
            rows="3"
          ></b-form-textarea>
        </b-form-group>

        <div class="d-flex justify-content-end">
          <b-button
            variant="secondary"
            class="mr-2"
            @click="$bvModal.hide('edit-request-modal')"
          >
            Cancel
          </b-button>
          <b-button
            type="submit"
            variant="primary"
            :disabled="submitting"
          >
            {{ submitting ? 'Updating...' : 'Update Request' }}
          </b-button>
        </div>
      </b-form>
    </b-modal>

    <!-- Logout Confirmation Modal -->
    <b-modal
      id="logout-confirm-modal"
      title="Confirm Logout"
      ok-title="Logout"
      ok-variant="danger"
      cancel-variant="outline-secondary"
      @ok="confirmLogout"
    >
      <p>Are you sure you want to log out?</p>
    </b-modal>
  </div>
</template>

<script>
export default {
  name: 'CustomerDashboard',
  data() {
    return {
      userInfo: JSON.parse(localStorage.getItem('userInfo') || '{}'),
      loading: false,
      submitting: false,
      searchQuery: '',
      selectedCategory: null,
      services: [],
      categories: [],
      serviceRequests: [],
      selectedService: null,
      selectedRequest: null,
      selectedRequestForEdit: null,
      bookingForm: {
        scheduled_date: '',
        address: '',
        special_instructions: ''
      },
      editForm: {
        scheduled_date: '',
        address: '',
        special_instructions: ''
      },
      reviewForm: {
        rating: 5,
        comment: ''
      },
      requestFields: [
        { key: 'service.name', label: 'Service' },
        { key: 'scheduled_date', label: 'Date' },
        { key: 'status', label: 'Status' },
        { key: 'actions', label: 'Actions' }
      ],
      ratingOptions: [
        { value: 1, text: '1 - Poor' },
        { value: 2, text: '2 - Fair' },
        { value: 3, text: '3 - Good' },
        { value: 4, text: '4 - Very Good' },
        { value: 5, text: '5 - Excellent' }
      ]
    }
  },
  computed: {
    categoryOptions() {
      return [
        { value: null, text: 'All Categories' },
        ...this.categories.map(category => ({
          value: category.id,
          text: category.name
        }))
      ]
    }
  },
  mounted() {
    this.fetchCategories()
    this.fetchServiceRequests()
  },
  methods: {
    async fetchCategories() {
      try {
        const response = await fetch('http://127.0.0.1:5000/api/service-categories')
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)
        this.categories = data
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error fetching categories', {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    async searchServices() {
      this.loading = true
      try {
        const queryParams = new URLSearchParams({
          q: this.searchQuery,
          category: this.selectedCategory || ''
        })
        const response = await fetch(`http://127.0.0.1:5000/api/customer/services/search?${queryParams}`)
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)
        this.services = data
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error searching services', {
          title: 'Error',
          variant: 'danger'
        })
      } finally {
        this.loading = false
      }
    },
    async fetchServiceRequests() {
      try {
        const token = localStorage.getItem('token')
        const response = await fetch('http://127.0.0.1:5000/api/customer/requests', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)
        this.serviceRequests = data
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error fetching requests', {
          title: 'Error',
          variant: 'danger'
        })
      }
    },
    bookService(service) {
      this.selectedService = service
      this.bookingForm = {...service,
        scheduled_date: '',
        address: '',
        special_instructions: ''
      }
      this.$bvModal.show('booking-modal')
    },
    async submitBooking() {
      this.submitting = true
      try {
        const token = localStorage.getItem('token')
        const response = await fetch('http://127.0.0.1:5000/api/customer/request-service', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            service_id: this.selectedService.id,
            ...this.bookingForm
          })
        })
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)
        
        this.$bvModal.hide('booking-modal')
        this.fetchServiceRequests()
        this.$bvToast.toast('Service requested successfully', {
          title: 'Success',
          variant: 'success'
        })
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error submitting request', {
          title: 'Error',
          variant: 'danger'
        })
      } finally {
        this.submitting = false
      }
    },
    showReviewModal(request) {
      this.selectedRequest = request
      this.reviewForm = {
        rating: 5,
        comment: ''
      }
      this.$bvModal.show('review-modal')
    },
    async submitReview() {
      this.submitting = true
      try {
        const token = localStorage.getItem('token')
        const response = await fetch(`http://127.0.0.1:5000/api/customer/reviews/${this.selectedRequest.id}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(this.reviewForm)
        })
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)

        this.$bvModal.hide('review-modal')
        this.fetchServiceRequests()
        this.$bvToast.toast('Review submitted successfully', {
          title: 'Success',
          variant: 'success'
        })
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error submitting review', {
          title: 'Error',
          variant: 'danger'
        })
      } finally {
        this.submitting = false
      }
    },
    showEditModal(request) {
      this.selectedRequestForEdit = request
      this.editForm = {
        scheduled_date: request.scheduled_date.slice(0, 16), // Format for datetime-local input
        address: request.address,
        special_instructions: request.special_instructions || ''
      }
      this.$bvModal.show('edit-request-modal')
    },async updateRequest() {
      this.submitting = true
      try {
        const response = await fetch(`http://127.0.0.1:5000/api/customer/requests/${this.selectedRequestForEdit.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify(this.editForm)
        })
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)

        this.$bvModal.hide('edit-request-modal')
        await this.fetchServiceRequests()
        this.$bvToast.toast('Request updated successfully', {
          title: 'Success',
          variant: 'success'
        })
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error updating request', {
          title: 'Error',
          variant: 'danger'
        })
      } finally {
        this.submitting = false
      }
    },

    async cancelRequest(requestId) {
      try {
        const response = await fetch(`http://127.0.0.1:5000/api/customer/requests/${requestId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
        const data = await response.json()
        if (!response.ok) throw new Error(data.error)

        await this.fetchServiceRequests()
        this.$bvToast.toast('Request cancelled successfully', {
          title: 'Success',
          variant: 'success'
        })
      } catch (error) {
        this.$bvToast.toast(error.message || 'Error cancelling request', {
          title: 'Error',
          variant: 'danger'
        })
      }
    },

    handleLogout() {
      this.$bvModal.show('logout-confirm-modal')
    },

    async confirmLogout() {
      try {
        localStorage.removeItem('token')
        localStorage.removeItem('userRole') 
        localStorage.removeItem('userInfo')
        
        this.$bvToast.toast('Logged out successfully', {
          title: 'Success',
          variant: 'success',
          toaster: 'b-toaster-top-center'
        })
        
        await this.$router.push('/login')
      } catch (error) {
        console.error('Logout error:', error)
        localStorage.clear()
        await this.$router.push('/login')
      }
    },

    formatDate(date) {
      return new Date(date).toLocaleString()
    },

    getStatusVariant(status) {
      const variants = {
        requested: 'warning',
        assigned: 'info',
        completed: 'success',
        rejected: 'danger',
        cancelled: 'secondary'
      }
      return variants[status] || 'secondary'
    }
  }
}
</script>

<style scoped>
.dashboard {
  margin-top: 1rem;
}
.card {
  margin-bottom: 1rem;
}
.badge {
  padding: 0.5em 1em;
}
.navbar {
  padding: 0.5rem 1rem;
}
.navbar-brand {
  font-weight: bold;
}
.nav-link {
  cursor: pointer;
}
.list-group-item {
  border-left: none;
  border-right: none;
}
.list-group-item:first-child {
  border-top: none;
}
.list-group-item:last-child {
  border-bottom: none;
}
</style>