<!-- src/components/auth/SignupForm.vue -->
<template>
    <div class="signup-container">
      <div class="signup-form">
        <h2>Create Account</h2>
        <form @submit.prevent="handleSignup" class="form">
          <!-- Basic user information -->
          <div class="form-group">
            <label for="username">Username</label>
            <input 
              type="text" 
              id="username" 
              v-model="formData.username" 
              required
              class="form-control"
            >
          </div>
  
          <div class="form-group">
            <label for="email">Email</label>
            <input 
              type="email" 
              id="email" 
              v-model="formData.email" 
              required
              class="form-control"
            >
          </div>
  
          <div class="form-group">
            <label for="password">Password</label>
            <input 
              type="password" 
              id="password" 
              v-model="formData.password" 
              required
              class="form-control"
            >
          </div>
  
          <div class="form-group">
            <label for="fullName">Full Name</label>
            <input 
              type="text" 
              id="fullName" 
              v-model="formData.full_name" 
              required
              class="form-control"
            >
          </div>
  
          <div class="form-group">
            <label for="role">Role</label>
            <select 
              id="role" 
              v-model="formData.role" 
              required
              class="form-control"
              @change="handleRoleChange"
            >
              <option value="Customer">Customer</option>
              <option value="Professional">Service Professional</option>
            </select>
          </div>
  
          <div class="form-group">
            <label for="phone">Phone</label>
            <input 
              type="tel" 
              id="phone" 
              v-model="formData.phone" 
              class="form-control"
            >
          </div>
  
          <div class="form-group">
            <label for="address">Address</label>
            <textarea 
              id="address" 
              v-model="formData.address" 
              class="form-control"
            ></textarea>
          </div>
  
          <!-- Professional specific fields -->
          <div v-if="formData.role === 'Professional'" class="professional-fields">
            <div class="form-group">
              <label for="experience">Years of Experience</label>
              <input 
                type="number" 
                id="experience" 
                v-model="formData.years_of_experience" 
                min="0"
                class="form-control"
              >
            </div>
  
            <div class="form-group">
              <label for="skills">Skills</label>
              <textarea 
                id="skills" 
                v-model="formData.skills" 
                class="form-control"
              ></textarea>
            </div>
  
            <div class="form-group">
              <label for="serviceCategory">Service Category</label>
              <select 
                id="serviceCategory" 
                v-model="formData.service_category_id" 
                class="form-control"
              >
                <option 
                  v-for="category in serviceCategories" 
                  :key="category.id" 
                  :value="category.id"
                >
                  {{ category.name }}
                </option>
              </select>
            </div>
  
            <div class="form-group">
              <label for="document">Verification Document</label>
              <input 
                type="file" 
                id="document" 
                @change="handleFileUpload" 
                class="form-control"
                accept=".pdf,.jpg,.jpeg,.png"
              >
            </div>
          </div>
  
          <div class="alert alert-danger" v-if="error">
            {{ error }}
          </div>
  
          <button type="submit" class="btn btn-primary" :disabled="isLoading">
            {{ isLoading ? 'Creating Account...' : 'Sign Up' }}
          </button>
        </form>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'SignupForm',
    data() {
      return {
        formData: {
          username: '',
          email: '',
          password: '',
          full_name: '',
          role: 'Customer',
          phone: '',
          address: '',
          years_of_experience: '',
          skills: '',
          service_category_id: '',
          document: null
        },
        serviceCategories: [],
        isLoading: false,
        error: null
      }
    },
    async created() {
      // Fetch service categories if needed
      if (this.formData.role === 'Professional') {
        await this.fetchServiceCategories()
      }
    },
    methods: {
      async fetchServiceCategories() {
        try {
          const response = await fetch('http://127.0.0.1:5000/api/service-categories')
          if (response.ok) {
            this.serviceCategories = await response.json()
          }
        } catch (error) {
          console.error('Error fetching service categories:', error)
        }
      },
      handleFileUpload(event) {
        this.formData.document = event.target.files[0]
      },
      handleRoleChange() {
        if (this.formData.role === 'Professional' && this.serviceCategories.length === 0) {
          this.fetchServiceCategories()
        }
      },
      async handleSignup() {
        this.isLoading = true
        this.error = null
  
        try {
          // Create FormData for file upload
          const formData = new FormData()
          
          // Add all form fields to FormData
          Object.keys(this.formData).forEach(key => {
            if (this.formData[key] !== '' && this.formData[key] !== null) {
              formData.append(key, this.formData[key])
            }
          })
  
          const response = await fetch('http://127.0.0.1:5000/api/auth/register', {
            method: 'POST',
            body: formData
          })
  
          const data = await response.json()
  
          if (!response.ok) {
            throw new Error(data.error || 'Registration failed')
          }
  
          // Registration successful
          alert('Registration successful! Please login.')
          this.$router.push('/login')
  
        } catch (err) {
          this.error = err.message
          console.error('Signup error:', err)
        } finally {
          this.isLoading = false
        }
      }
    }
  }
  </script>
  
  <style scoped>
  .signup-container {
    max-width: 600px;
    margin: 30px auto;
    padding: 20px;
  }
  
  .signup-form {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }
  
  .form-group {
    margin-bottom: 15px;
  }
  
  .form-control {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-top: 5px;
  }
  
  .btn {
    width: 100%;
    padding: 10px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .btn:disabled {
    background: #ccc;
  }
  
  .alert {
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 4px;
  }
  
  .alert-danger {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  .professional-fields {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #eee;
  }
  </style>