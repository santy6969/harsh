//LoginForm.vue
<template>
  <div class="login">
    <form @submit.prevent="handleLogin">
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Email address</label>
        <input 
          v-model="loginform.email" 
          type="email" 
          class="form-control" 
          id="exampleInputEmail1" 
          aria-describedby="emailHelp"
        >
        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
      </div>
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input 
          v-model="loginform.password" 
          type="password" 
          class="form-control" 
          id="exampleInputPassword1"
        >
      </div>
      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Check me out</label>
      </div>
      <button type="submit" class="btn btn-primary" :disabled="loading">
        {{ loading ? 'Loading...' : 'Submit' }}
      </button>
    </form>
  </div>
</template>

<script>
export default {
  name: 'LoginForm',
  data() {
    return {
      loginform: {
        email: '',
        password: ''
      },
      loading: false
    }
  },
  methods: {
    async handleLogin() {
      if (this.loading) return
      
      this.loading = true
      try {
        const response = await fetch('http://127.0.0.1:5000/api/auth/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.loginform)
        });

        const data = await response.json()
        
        if (!response.ok) {
          throw new Error(data.error || 'Login failed')
        }

        // Store authentication data
        localStorage.setItem('token', data.token)
        localStorage.setItem('userRole', data.user.role)

        // Navigate based on role using replace instead of push
        const role = data.user.role
        let path = '/login' // default path

        if (role === 'Admin') path = '/admin'
        else if (role === 'Customer') path = '/user/customer'
        else if (role === 'Professional') path = '/user/professional'

        await this.$router.replace(path)
        
      } catch (error) {
        console.error('Error:', error)
        alert(error.message || 'Login failed')
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style scoped>
.login {
  max-width: 400px;
  margin: 2rem auto;
  padding: 1rem;
}

.btn-primary {
  width: 100%;
}
</style>