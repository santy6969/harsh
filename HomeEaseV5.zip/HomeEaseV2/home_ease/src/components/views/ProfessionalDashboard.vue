<!-- ProfessionalDashboard.vue -->
<template>
    <div>
      <!-- Navigation Bar -->
      <b-navbar variant="dark" type="dark" class="mb-4 bg-primary">
        <b-navbar-brand>Professional Dashboard</b-navbar-brand>
        <b-navbar-nav class="ml-auto">
          <!-- Profile and Logout Dropdown -->
          <b-nav-item-dropdown right>
            <template #button-content>
              <b-icon icon="person-fill" class="mr-1"></b-icon>
              {{ userInfo.full_name || 'Professional' }}
            </template>
            <b-dropdown-item @click="handleLogout">
              <b-icon icon="box-arrow-right" class="mr-1"></b-icon>
              Logout
            </b-dropdown-item>
          </b-nav-item-dropdown>
        </b-navbar-nav>
      </b-navbar>
  
      <div class="dashboard container py-4">
        <!-- Statistics Cards -->
        <b-row class="mb-4">
          <b-col md="4">
            <b-card bg-variant="info" text-variant="white">
              <h5>Total Requests</h5>
              <h2>{{ stats.totalRequests }}</h2>
            </b-card>
          </b-col>
          <b-col md="4">
            <b-card bg-variant="success" text-variant="white">
              <h5>Completed Services</h5>
              <h2>{{ stats.completedRequests }}</h2>
            </b-card>
          </b-col>
          <b-col md="4">
            <b-card bg-variant="warning" text-variant="white">
              <h5>Average Rating</h5>
              <h2>{{ stats.averageRating }}/5</h2>
            </b-card>
          </b-col>
        </b-row>
  
        <!-- Service Requests Tabs -->
        <b-card no-body>
          <b-tabs pills card>
            <!-- Today's Requests -->
            <b-tab title="Today's Requests" active>
              <b-table
                :items="todayRequests"
                :fields="requestFields"
                striped
                hover
                responsive
              >
                <template #cell(customer)="{ item }">
                  <div>
                    <strong>{{ item.customer_name }}</strong>
                    <div class="small text-muted">{{ item.customer_phone }}</div>
                  </div>
                </template>
  
                <template #cell(service)="{ item }">
                  <div>
                    <div>{{ item.service_name }}</div>
                    <div class="small text-muted">{{ formatDate(item.scheduled_date) }}</div>
                  </div>
                </template>
  
                <template #cell(status)="{ item }">
                  <b-badge :variant="getStatusVariant(item.status)">
                    {{ item.status }}
                  </b-badge>
                </template>
  
                <template #cell(actions)="{ item }">
                  <b-button-group size="sm">
                    <b-button
                      v-if="item.status === 'requested'"
                      variant="success"
                      @click="handleRequest(item, 'accept')"
                      :disabled="loading"
                    >
                      Accept
                    </b-button>
                    <b-button
                      v-if="item.status === 'requested'"
                      variant="danger"
                      @click="handleRequest(item, 'reject')"
                      :disabled="loading"
                    >
                      Reject
                    </b-button>
                    <b-button
                      v-if="item.status === 'assigned'"
                      variant="primary"
                      @click="handleRequest(item, 'complete')"
                      :disabled="loading"
                    >
                      Complete
                    </b-button>
                  </b-button-group>
                </template>
              </b-table>
            </b-tab>
  
            <!-- All Requests -->
            <b-tab title="All Requests">
              <b-row class="mb-3">
                <b-col md="6">
                  <b-form-group label="Filter by Status">
                    <b-form-select v-model="filter.status" :options="statusOptions">
                    </b-form-select>
                  </b-form-group>
                </b-col>
                <b-col md="6">
                  <b-form-group label="Search Customer">
                    <b-form-input
                      v-model="filter.search"
                      placeholder="Search by customer name..."
                      @input="filterRequests"
                    ></b-form-input>
                  </b-form-group>
                </b-col>
              </b-row>
  
              <b-table
                :items="filteredRequests"
                :fields="requestFields"
                striped
                hover
                responsive
              >
                <!-- Same cell templates as above -->
                <template #cell(customer)="{ item }">
                  <div>
                    <strong>{{ item.customer_name }}</strong>
                    <div class="small text-muted">{{ item.customer_phone }}</div>
                  </div>
                </template>
  
                <template #cell(service)="{ item }">
                  <div>
                    <div>{{ item.service_name }}</div>
                    <div class="small text-muted">{{ formatDate(item.scheduled_date) }}</div>
                  </div>
                </template>
  
                <template #cell(status)="{ item }">
                  <b-badge :variant="getStatusVariant(item.status)">
                    {{ item.status }}
                  </b-badge>
                </template>
  
                <template #cell(actions)="{ item }">
                  <b-button-group size="sm">
                    <b-button
                      v-if="item.status === 'requested'"
                      variant="success"
                      @click="handleRequest(item, 'accept')"
                      :disabled="loading"
                    >
                      Accept
                    </b-button>
                    <b-button
                      v-if="item.status === 'requested'"
                      variant="danger"
                      @click="handleRequest(item, 'reject')"
                      :disabled="loading"
                    >
                      Reject
                    </b-button>
                    <b-button
                      v-if="item.status === 'assigned'"
                      variant="primary"
                      @click="handleRequest(item, 'complete')"
                      :disabled="loading"
                    >
                      Complete
                    </b-button>
                  </b-button-group>
                </template>
              </b-table>
            </b-tab>
  
            <!-- Reviews Tab -->
            <b-tab title="Reviews">
              <template v-if="reviews">
                <div class="reviews-list">
                  <div  class="review-item p-3 border-bottom">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                      <div>
                        <b-badge variant="info">{{ reviews.service_request_id }}</b-badge>
                        <span class="text-muted ml-2">{{ formatDate(reviews.created_at) }}</span>
                      </div>
                      <div class="rating">
                        <b-icon icon="star-fill" variant="warning"></b-icon>
                        {{ reviews.rating }}/5
                      </div>
                    </div>
                    <p class="mb-0">{{ reviews.comment }}</p>
                  </div>
                </div>
              </template>
              <template v-else>
                <p class="text-center py-4">No reviews yet</p>
              </template>
            </b-tab>
          </b-tabs>
        </b-card>
      </div>
  
      <!-- Logout Confirmation Modal -->
      <b-modal
        id="logout-confirm-modal"
        title="Confirm Logout"
        ok-title="Logout"
        ok-variant="danger"
        cancel-variant="outline-secondary"
        @ok="confirmLogout"
      >
        <p>Are you sure you want to log out?</p>
      </b-modal>
    </div>
  </template>
  
  <script>
  export default {
    name: 'ProfessionalDashboard',
    data() {
      return {
        userInfo: JSON.parse(localStorage.getItem('userInfo') || '{}'),
        loading: false,
        requests: [],
        reviews: [],
        stats: {
          totalRequests: 0,
          completedRequests: 0,
          averageRating: 0
        },
        filter: {
          status: null,
          search: ''
        },
        requestFields: [
          { key: 'customer', label: 'Customer' },
          { key: 'service', label: 'Service' },
          { key: 'status', label: 'Status' },
          { key: 'actions', label: 'Actions' }
        ],
        statusOptions: [
          { value: null, text: 'All Status' },
          { value: 'requested', text: 'Requested' },
          { value: 'assigned', text: 'Assigned' },
          { value: 'completed', text: 'Completed' },
          { value: 'rejected', text: 'Rejected' }
        ]
      }
    },
    computed: {
      todayRequests() {
        const today = new Date().toISOString().split('T')[0]
        return this.requests.filter(request => 
          request.scheduled_date.startsWith(today)
        )
      },
      filteredRequests() {
        return this.requests.filter(request => {
          const matchesStatus = !this.filter.status || request.status === this.filter.status
          const matchesSearch = !this.filter.search || 
            request.customer_name.toLowerCase().includes(this.filter.search.toLowerCase())
          return matchesStatus && matchesSearch
        })
      }
    },
    mounted() {
      this.fetchRequests()
      this.fetchStats()
    },
    methods: {
      async fetchRequests() {
        try {
          const token = localStorage.getItem('token')
          const response = await fetch('http://127.0.0.1:5000/api/professional/requests', {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          })
          const data = await response.json()
          if (!response.ok) throw new Error(data.error)
          this.requests = data
          this.reviews = data[1].review
        } catch (error) {
          this.$bvToast.toast(error.message || 'Error fetching requests', {
            title: 'Error',
            variant: 'danger'
          })
        }
      },
      async handleRequest(request, action) {
        this.loading = true
        try {
          const token = localStorage.getItem('token')
          const response = await fetch(`http://127.0.0.1:5000/api/professional/requests/${request.id}/action`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ action })
          })
          const data = await response.json()
          if (!response.ok) throw new Error(data.error)
          
          this.$bvToast.toast(`Request ${action}ed successfully`, {
            title: 'Success',
            variant: 'success'
          })
          
          await this.fetchRequests()
          await this.fetchStats()
        } catch (error) {
          this.$bvToast.toast(error.message || `Error ${action}ing request`, {
            title: 'Error',
            variant: 'danger'
          })
        } finally {
          this.loading = false
        }
      },
      async fetchStats() {
        try {
          this.stats = {
            totalRequests: this.requests.length,
            completedRequests: this.requests.filter(r => r.status === 'completed').length,
            averageRating: 4.5 // You might want to calculate this from your reviews
          }
        } catch (error) {
          console.error('Error calculating stats:', error)
        }
      },
      filterRequests() {
        // No need to do anything here as we're using a computed property
      },
      handleLogout() {
        this.$bvModal.show('logout-confirm-modal')
      },
      async confirmLogout() {
        try {
          localStorage.removeItem('token')
          localStorage.removeItem('userRole')
          localStorage.removeItem('userInfo')
          
          this.$bvToast.toast('Logged out successfully', {
            title: 'Success',
            variant: 'success',
            toaster: 'b-toaster-top-center'
          })
          
          await this.$router.push('/login')
        } catch (error) {
          console.error('Logout error:', error)
          localStorage.clear()
          await this.$router.push('/login')
        }
      },
      formatDate(date) {
        return new Date(date).toLocaleString()
      },
      getStatusVariant(status) {
        const variants = {
          requested: 'warning',
          assigned: 'info',
          completed: 'success',
          rejected: 'danger'
        }
        return variants[status] || 'secondary'
      }
    }
  }
  </script>
  
  <style scoped>
  .dashboard {
    margin-top: 1rem;
  }
  .card {
    margin-bottom: 1rem;
  }
  .badge {
    padding: 0.5em 1em;
  }
  .navbar {
    padding: 0.5rem 1rem;
  }
  .navbar-brand {
    font-weight: bold;
  }
  .review-item {
    transition: background-color 0.2s;
  }
  .review-item:hover {
    background-color: #f8f9fa;
  }
  .button-group > .btn {
    margin-right: 0.2rem;
  }
  </style>