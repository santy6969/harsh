<!-- src/components/NavBar.vue -->
<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <router-link class="navbar-brand" to="/">HomeEase</router-link>
      <div class="navbar-nav ml-auto">
        <router-link class="nav-link" to="/signup">Sign Up</router-link>
        <router-link class="nav-link" to="/login">Login</router-link>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: 'NavBar'
}
</script>