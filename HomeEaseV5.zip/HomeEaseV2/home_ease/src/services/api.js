// src/main.js
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue'

// Import Bootstrap and BootstrapVue CSS files
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'bootstrap-vue/dist/bootstrap-vue-icons.min.css'

// Make BootstrapVue and its icons available throughout your project
Vue.use(BootstrapVue)
Vue.use(BootstrapVueIcons)

// Custom error handler
Vue.config.errorHandler = (err, vm) => {
  console.error(err)
  vm.$bvToast.toast(err.message || 'An error occurred', {
    title: 'Error',
    variant: 'danger',
    toaster: 'b-toaster-top-center'
  })
}

// Production tip
Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')