<!-- src/App.vue -->
<template>
  <div id="app">
    <NavBar/>
    <router-view></router-view>
  </div>
</template>

<script>
import NavBar from './components/NavBar'


export default {
  name: 'App',
  components:{
    NavBar,
  }
}
</script>

<style>
/* Your existing styles */
</style>