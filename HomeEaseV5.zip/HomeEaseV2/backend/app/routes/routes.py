# routes/__init__.py
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, create_access_token, get_jwt_identity
from datetime import datetime
from models import db, User, Service, Professional, ServiceRequest, Review, ServiceCategory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask import current_app as app
import os
from sqlalchemy import or_

api = Blueprint('api', __name__)

# Authentication Routes
@api.route('/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        user = User.query.filter_by(email=data['email']).first()
        print(data)
        if user and user.check_password(data['password']):
            if user.status == 'blocked':
                return jsonify({'error': 'Account is blocked'}), 403
                           
            access_token = create_access_token(identity={
                'id': user.id,
                'role': user.role
            })
            
            # Update last login
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            return jsonify({
                'token': access_token,
                'user': user.to_dict()
            }), 200
            
        return jsonify({'error': 'Invalid credentials'}), 401
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/auth/register', methods=['POST'])
def register():
    try:
        if request.content_type == 'application/json':
            data = request.get_json()
            username = data['username']
        else:
            data = request.form

        # Check if email exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already registered'}), 409

        # Create new user
        new_user = User(
            username=data['username'],
            email=data['email'],
            role=data['role'],
            full_name=data['full_name'],
            phone=data.get('phone'),
            address=data.get('address')
        )
        new_user.set_password(data['password'])
        
        db.session.add(new_user)
        db.session.commit()

        # If professional, create professional profile
        username = new_user.username

        if data['role'] == 'Professional':
            new_professional = Professional(
                user_id=new_user.id,
                service_category_id=data['service_category_id'],
                years_of_experience=data['years_of_experience'],
                skills=data.get('skills'),
                verification_status='pending'
            )
            
            if 'document' in request.files:
                file = request.files['document']
                filename = secure_filename(f'{username}.pdf')
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                new_professional.document_url = file_path
                

            db.session.add(new_professional)
            db.session.commit()

        return jsonify({'message': 'Registration successful'}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# In your Flask routes
@api.route('/service-categories', methods=['GET'])
def get_service_categories():
    categories = ServiceCategory.query.filter_by(is_active=True).all()
    return jsonify([category.to_dict() for category in categories])

# Admin Routes
@api.route('/admin/dashboard/stats', methods=['GET'])
@jwt_required()
def get_admin_stats():
    try:
        stats = {
            'total_customers': User.query.filter_by(role='Customer').count(),
            'total_professionals': Professional.query.count(),
            'pending_verifications': Professional.query.filter_by(verification_status='pending').count(),
            'total_services': Service.query.count(),
            'total_requests': ServiceRequest.query.count(),
            'completed_requests': ServiceRequest.query.filter_by(status='completed').count()
        }
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/admin/services', methods=['GET', 'POST'])
@jwt_required()
def manage_services():
    try:
        if request.method == 'GET':
            services = Service.query.all()
            return jsonify([service.to_dict() for service in services])
        elif request.method == 'POST':
            data = request.get_json()
            print(data)
            new_service = Service(
                name=data['name'],
                description=data['description'],
                base_price=float(data['base_price']),
                category_id=data['category_id'],
                estimated_time=data.get('estimated_time')
            )
            db.session.add(new_service)
            db.session.commit()
            return jsonify(new_service.to_dict()), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api.route('/admin/professionals/verify/<int:professional_id>', methods=['POST'])
@jwt_required()
def verify_professional(professional_id):
    try:
        professional = Professional.query.get_or_404(professional_id)
        professional.verification_status = 'verified'
        db.session.commit()
        return jsonify({'message': 'Professional verified successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api.route('/admin/users/block/<int:user_id>', methods=['POST'])
@jwt_required()
def block_user(user_id):
    try:
        user = User.query.get_or_404(user_id)
        user.status = 'blocked' if user.status == 'active' else 'active'
        db.session.commit()
        return jsonify({'message': f'User {user.status} successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Professional Routes
@api.route('/professional/requests', methods=['GET'])
@jwt_required()
def get_professional_requests():
    try:
        claims = get_jwt_identity()
        professional = Professional.query.filter_by(user_id=claims['id']).first()
        # print(professional)
        if not professional:
            return jsonify({'error': 'Professional profile not found'}), 404
            
        requests = ServiceRequest.query.filter_by(professional_id=None).all()
        prof_req = ServiceRequest.query.filter_by(professional_id=professional.id).all()
        # print(requests)
        # print(prof_req)
        # print([request.to_dict() for request in requests],[req.to_dict() for req in prof_req])
        return jsonify([request.to_dict() for request in requests]+[req.to_dict() for req in prof_req])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/professional/requests/<int:request_id>/action', methods=['POST'])
@jwt_required()
def handle_request(request_id):
    try:
        data = request.get_json()
        service_request = ServiceRequest.query.get_or_404(request_id)
        current_user = get_jwt_identity()
        
        action = data['action']
        if action == 'accept':
            service_request.status = 'assigned'
            prof = Professional.query.filter_by(user_id=current_user['id']).first()
            service_request.professional_id = prof.id
        elif action == 'reject':
            service_request.status = 'rejected'
        elif action == 'complete':
            service_request.status = 'completed'
            service_request.completed_at = datetime.utcnow()
            
        db.session.commit()
        return jsonify({'message': f'Request {action}ed successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Customer Routes
@api.route('/customer/services/search', methods=['GET'])
def search_services():
    try:
        query = request.args.get('q', '')
        category = request.args.get('category')
        
        services = Service.query.filter(Service.name.ilike(f'%{query}%'))
        if category:
            services = services.filter_by(category_id=category)
            
        return jsonify([service.to_dict() for service in services.all()])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/customer/request-service', methods=['POST'])
@jwt_required()
def request_service():
    try:
        data = request.get_json()
        claims = get_jwt_identity()

        print(data)
        
        service_request = ServiceRequest(
            customer_id=claims['id'],
            service_id=data['service_id'],
            scheduled_date=datetime.fromisoformat(data['scheduled_date']),
            address=data['address'],
            special_instructions=data.get('special_instructions'),
            status='requested'
        )
        
        db.session.add(service_request)
        db.session.commit()
        return jsonify(service_request.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api.route('/customer/reviews/<int:request_id>', methods=['POST'])
@jwt_required()
def submit_review(request_id):
    try:
        data = request.get_json()
        claims = get_jwt_identity()
        
        service_request = ServiceRequest.query.get_or_404(request_id)
        if service_request.customer_id != claims['id']:
            return jsonify({'error': 'Unauthorized'}), 403
            
        if service_request.status != 'completed':
            return jsonify({'error': 'Cannot review incomplete service'}), 400
            
        review = Review(
            service_request_id=request_id,
            rating=data['rating'],
            comment=data.get('comment')
        )
        
        db.session.add(review)
        
        # Update professional's average rating
        professional = service_request.professional
        reviews = Review.query.join(ServiceRequest).filter(
            ServiceRequest.professional_id == professional.id
        ).all()
        professional.average_rating = sum(r.rating for r in reviews) / len(reviews)
        professional.total_services += 1
        
        db.session.commit()
        return jsonify(review.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@api.route('/customer/requests', methods=['GET'])
@jwt_required()
def get_customer_requests():
    try:
        claims = get_jwt_identity()
        status_filter = request.args.get('status')
        
        requests = ServiceRequest.query.filter_by(customer_id=claims['id'])
        if status_filter:
            requests = requests.filter_by(status=status_filter)
            
        return jsonify([request.to_dict() for request in requests.all()])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/customer/requests/<int:request_id>', methods=['PUT'])
@jwt_required()
def update_customer_request(request_id):
    try:
        claims = get_jwt_identity()
        data = request.get_json()
        
        service_request = ServiceRequest.query.get_or_404(request_id)
        if service_request.customer_id != claims['id']:
            return jsonify({'error': 'Unauthorized'}), 403
            
        if service_request.status not in ['requested', 'pending']:
            return jsonify({'error': 'Cannot modify request in current status'}), 400
            
        service_request.scheduled_date = datetime.fromisoformat(data.get('scheduled_date', service_request.scheduled_date))
        service_request.address = data.get('address', service_request.address)
        service_request.special_instructions = data.get('special_instructions')
        
        db.session.commit()
        return jsonify(service_request.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api.route('/customer/requests/<int:request_id>', methods=['DELETE'])
@jwt_required()
def cancel_customer_request(request_id):
    try:
        claims = get_jwt_identity()
        service_request = ServiceRequest.query.get_or_404(request_id)
        
        if service_request.customer_id != claims['id']:
            return jsonify({'error': 'Unauthorized'}), 403
            
        if service_request.status not in ['requested', 'pending']:
            return jsonify({'error': 'Cannot cancel request in current status'}), 400
            
        service_request.status = 'cancelled'
        db.session.commit()
        return jsonify({'message': 'Request cancelled successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Error handlers
@api.errorhandler(404)
def not_found_error(error):
    return jsonify({'error': 'Resource not found'}), 404

@api.errorhandler(401)
def unauthorized_error(error):
    return jsonify({'error': 'Unauthorized access'}), 401

@api.errorhandler(403)
def forbidden_error(error):
    return jsonify({'error': 'Forbidden action'}), 403

@api.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({'error': 'Internal server error'}), 500

# Add these routes to your Flask backend

@api.route('/admin/users', methods=['GET'])
@jwt_required()
def get_users():
    try:
        users = User.query.all()
        return jsonify([user.to_dict() for user in users])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/admin/professionals/pending', methods=['GET'])
@jwt_required()
def get_pending_professionals():
    try:
        pending = Professional.query.filter_by(verification_status='pending').all()
        professionals_data = []
        for prof in pending:
            user = User.query.get(prof.user_id)
            prof_data = prof.to_dict()
            prof_data.update({
                'full_name': user.full_name,
                'email': user.email,
                'status': user.status
            })
            professionals_data.append(prof_data)
        return jsonify(professionals_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500