# models.py
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    """User model for all types of users (Admin, Professional, Customer)"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'Admin', 'Professional', 'Customer'
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=True)  # Made nullable for admin
    address = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), default='active')  # 'active', 'blocked'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    # Relationships
    professional_profile = db.relationship('Professional', backref='user', uselist=False)
    customer_requests = db.relationship('ServiceRequest', backref='customer', lazy=True,
                                      foreign_keys='ServiceRequest.customer_id')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'full_name': self.full_name,
            'status': self.status,
            'phone': self.phone,
            'address': self.address
        }

class Professional(db.Model):
    """Model for service professionals"""
    __tablename__ = 'professionals'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    service_category_id = db.Column(db.Integer, db.ForeignKey('service_categories.id'))
    years_of_experience = db.Column(db.Integer, nullable=False)
    skills = db.Column(db.Text, nullable=True)
    verification_status = db.Column(db.String(20), default='pending')  # 'pending', 'verified', 'rejected'
    document_url = db.Column(db.String(255), nullable=True)
    average_rating = db.Column(db.Float, default=0.0)
    total_services = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    assigned_requests = db.relationship('ServiceRequest', backref='professional', lazy=True,
                                      foreign_keys='ServiceRequest.professional_id')
    service_category = db.relationship('ServiceCategory', backref='professionals')

    def to_dict(self):
        return {
            'id': self.id,
            'user': self.user.to_dict(),
            'service_category': self.service_category.to_dict() if self.service_category else None,
            'years_of_experience': self.years_of_experience,
            'skills': self.skills,
            'verification_status': self.verification_status,
            'average_rating': self.average_rating,
            'total_services': self.total_services
        }

class ServiceCategory(db.Model):
    """Model for service categories"""
    __tablename__ = 'service_categories'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=True)
    image_url = db.Column(db.String(255), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    services = db.relationship('Service', backref='category', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'image_url': self.image_url,
            'is_active': self.is_active
        }

class Service(db.Model):
    """Model for specific services within categories"""
    __tablename__ = 'services'

    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('service_categories.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    base_price = db.Column(db.Float, nullable=False)
    estimated_time = db.Column(db.String(50), nullable=True)
    image_url = db.Column(db.String(255), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    requests = db.relationship('ServiceRequest', backref='service', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'category_id': self.category_id,
            'name': self.name,
            'description': self.description,
            'base_price': self.base_price,
            'estimated_time': self.estimated_time,
            'image_url': self.image_url,
            'is_active': self.is_active
        }

class ServiceRequest(db.Model):
    """Model for service requests from customers"""
    __tablename__ = 'service_requests'

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey('professionals.id'), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='requested')  
    scheduled_date = db.Column(db.DateTime, nullable=False)
    address = db.Column(db.Text, nullable=False)
    special_instructions = db.Column(db.Text, nullable=True)
    total_amount = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)

    # Relationships
    review = db.relationship('Review', backref='service_request', uselist=False)

    def to_dict(self):
        return {
            'id': self.id,
            'customer': self.customer.to_dict(),
            'service': self.service.to_dict(),
            'professional': self.professional.to_dict() if self.professional else None,
            'status': self.status,
            'scheduled_date': self.scheduled_date.isoformat() if self.scheduled_date else None,
            'address': self.address,
            'special_instructions': self.special_instructions,
            'total_amount': self.total_amount,
            'created_at': self.created_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'review': self.review.to_dict() if self.review else None
        }

class Review(db.Model):
    """Model for service reviews and ratings"""
    __tablename__ = 'reviews'

    id = db.Column(db.Integer, primary_key=True)
    service_request_id = db.Column(db.Integer, db.ForeignKey('service_requests.id'), unique=True)
    rating = db.Column(db.Integer, nullable=False)  # 1 to 5
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'service_request_id': self.service_request_id,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat()
        }