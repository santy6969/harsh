# app.py
from flask import Flask
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from datetime import timedelta
import os
from models import db, User, Professional, Service, ServiceRequest, Review, ServiceCategory
from werkzeug.security import generate_password_hash

def create_app():
    # Initialize Flask app
    app = Flask(__name__)

    # Configuration
    app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this in production
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.sqlite3'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = 'jwt-secret-key'  # Change this in production
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)

    # Upload configuration
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

    # Ensure upload directory exists
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    # Initialize extensions with app
    db.init_app(app)
    jwt = JWTManager(app)
    CORS(app)

    # Import and register blueprints
    from routes.routes import api
    app.register_blueprint(api, url_prefix='/api')

    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return {'error': 'Resource not found'}, 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return {'error': 'Internal server error'}, 500

    return app

def init_db(app):
    """Initialize the database and create initial data."""
    with app.app_context():
        # Create database tables
        db.create_all()
        
        # Create admin if not exists
        admin = User.query.filter_by(role='Admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@example.com',
                password_hash=generate_password_hash('admin123'),  # Change this password
                role='Admin',
                full_name='System Admin',
                status='active'
            )
            db.session.add(admin)
            db.session.commit()
            print("Admin user created successfully!")

        # Initialize service categories
        if ServiceCategory.query.count() == 0:
            categories = [
                {
                    "name": "Plumbing Services",
                    "description": "Professional plumbing services including repairs, installations, and maintenance"
                },
                {
                    "name": "Electrical Services",
                    "description": "Expert electrical work, installations, repairs, and safety inspections"
                },
                {
                    "name": "AC Services",
                    "description": "AC installation, repair, maintenance, and servicing"
                },
                {
                    "name": "Home Cleaning",
                    "description": "Professional home cleaning and sanitization services"
                },
                {
                    "name": "Pest Control",
                    "description": "Complete pest control solutions for your home"
                }
            ]
            
            for category in categories:
                new_category = ServiceCategory(
                    name=category["name"],
                    description=category["description"]
                )
                db.session.add(new_category)
            
            db.session.commit()
            print("Service categories initialized successfully!")

if __name__ == '__main__':
    # Create and configure the app
    app = create_app()
    
    # Initialize the database
    init_db(app)
    
    # Run the application
    app.run(debug=True, host='0.0.0.0', port=5000)